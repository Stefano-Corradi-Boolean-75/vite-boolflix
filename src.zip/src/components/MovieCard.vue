<script>
export default {
  name: 'MovieCard',
  props:{
    card: Object
  }
}
</script>

<template>

  <div> - {{ card.title || card.name }} - </div>
  
</template>


<style lang="scss" scoped>

</style>